<?php $__env->startSection('content'); ?>
<script src="https://cdn.tiny.cloud/1/yoabqynrahzewkgm5ww00xi1i9wnw5s4kd0lxfpcmb8liwth/tinymce/5/tinymce.min.js" referrerpolicy="origin"></script>
<script>
    tinymce.init({
        selector: '#mota',
        plugins: ["advlist autolink lists link image charmap print preview anchor textcolor textcolor colorpicker",
            "searchreplace visualblocks code fullscreen",
            "insertdatetime media table contextmenu paste"],
        toolbar: 'undo redo | bold italic underline | forecolor fontsizeselect |  numlist bullist checklist | alignleft aligncenter alignright link image',
        automatic_uploads: true,
        images_upload_url: '/admin/upload',
        images_reuse_filename: true,
        content_css: ["/css/style.css", "/css/admin-style.css"]
    });
</script>
<div class="container">
    <!-- Content (replace with your e-mail address below)
    ================================================== -->
    <div class="main-content">
        <section>
            <div class="section-title">
                <h2><span>Gây quỹ từ thiện công khai</span></h2>
            </div>
            <div class="article-post">
                <form action="gay-quy" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-group row">
                        <div class="col-md-6">
                            <label>Hình ảnh dại diện <span class="text-danger text-center">*</span></label>
                            <input class="form-control" type="file" name="image" accept="image/jpeg,image/png,image/jpg,image/gif,image/tiff,image/svg" >
                            <?php if($errors->first('image')): ?>
                                <small id="emailHelp" class="form-text text-danger"><?php echo e($errors->first('image')); ?></small>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-md-6">
                            <label>Tên quỹ từ thiện <span class="text-danger text-center">*</span></label>
                            <input class="form-control" type="text" name="tenquy" placeholder="Tên quỹ từ thiện" value="<?php echo e(old('tenquy')); ?>">
                            <?php if($errors->first('tenquy')): ?>
                                <small id="emailHelp" class="form-text text-danger"><?php echo e($errors->first('tenquy')); ?></small>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-md-6">
                            <label>Ngày bắt đầu</label>
                            <input class="form-control" type="date" name="batdau" value="<?php echo e(old('batdau') ?? date('Y-m-d')); ?>">
                            <?php if($errors->first('batdau')): ?>
                                <small id="emailHelp" class="form-text text-danger"><?php echo e($errors->first('batdau')); ?></small>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-6">
                            <label>Ngày kết thúc</label>
                            <input class="form-control" type="date" name="ketthuc" value="<?php echo e(old('ketthuc') ?? date('Y-m-d')); ?>">
                            <?php if($errors->first('ketthuc')): ?>
                                <small id="emailHelp" class="form-text text-danger"><?php echo e($errors->first('ketthuc')); ?></small>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="section-title">
                        <h2><span>Thông tin ngân hàng tiếp nhận quyên gớp</span></h2>
                    </div>
                    <?php if(old('taikhoan')): ?>
                    <?php $__currentLoopData = old('taikhoan'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-group row">
                        <div class="col-md-3">
                            <input class="form-control" type="text" name="taikhoan[<?php echo e($key); ?>][nganhang]" placeholder="Tên ngân hàng" value="<?php echo e($item['nganhang']); ?>">
                            <?php if($errors->first('taikhoan.'.$key.'.nganhang')): ?>
                                <small id="emailHelp" class="form-text text-danger"><?php echo e($errors->first('taikhoan.'.$key.'.nganhang')); ?></small>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-3">
                            <input class="form-control" type="text" name="taikhoan[<?php echo e($key); ?>][ma_taikhoan]" placeholder="Tài khoản" value="<?php echo e($item['ma_taikhoan']); ?>">
                            <?php if($errors->first('taikhoan.'.$key.'.ma_taikhoan')): ?>
                                <small id="emailHelp" class="form-text text-danger"><?php echo e($errors->first('taikhoan.'.$key.'.ma_taikhoan')); ?></small>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-6">
                            <div class='row'>
                                <div class="col-md-8">
                                    <input class="form-control" type="text" name="taikhoan[<?php echo e($key); ?>][hoten]" placeholder="Chủ sở hữu" value="<?php echo e($item['hoten']); ?>">
                                    <?php if($errors->first('taikhoan.'.$key.'.hoten')): ?>
                                        <small id="emailHelp" class="form-text text-danger"><?php echo e($errors->first('taikhoan.'.$key.'.hoten')); ?></small>
                                    <?php endif; ?>
                                </div>
                                <div class="col-md-4">
                                    <?php if($key == 0): ?>
                                    <button type="button" onclick="add(this)" class="btn btn-primary">Thêm</button>
                                    <?php else: ?>
                                    <button type="button" onclick="remove(this)" class="btn btn-danger">Xóa</button>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                    
                    <div class="form-group row">
                        <div class="col-md-3">
                            <input class="form-control" type="text" name="taikhoan[0][nganhang]" placeholder="Tên ngân hàng (*)">
                        </div>
                        <div class="col-md-3">
                            <input class="form-control" type="text" name="taikhoan[0][ma_taikhoan]" placeholder="Tài khoản (*)">
                        </div>
                        <div class="col-md-6">
                            <div class='row'>
                                <div class="col-md-8">
                                    <input class="form-control" type="text" name="taikhoan[0][hoten]" placeholder="Chủ sở hữu (*)">
                                </div>
                                <div class="col-md-4">
                                    <button type="button" class="btn btn-primary" onclick="add(this)">Thêm</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                    <div class="section-title">
                        <h2><span>Thông tin người phụ trách quyên gớp</span></h2>
                    </div>
                    <div class="form-group row">
                        <div class="col-md-6">
                            <input class="form-control" type="text" name="phutrach" placeholder="Họ tên (bắt buộc)" value="<?php echo e(old('phutrach')); ?>">
                            <?php if($errors->first('phutrach')): ?>
                                <small id="emailHelp" class="form-text text-danger"><?php echo e($errors->first('phutrach')); ?></small>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-6">
                            <input class="form-control" type="text" name="diachi" placeholder="Địa chỉ" value="<?php echo e(old('diachi')); ?>">
                            <?php if($errors->first('diachi')): ?>
                                <small id="emailHelp" class="form-text text-danger"><?php echo e($errors->first('diachi')); ?></small>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-md-6">
                            <input class="form-control" type="phone" name="sdt" maxlength="12" placeholder="Số điện thoại (bắt buộc 1 trong 2)" value="<?php echo e(old('sdt')); ?>">
                            <?php if($errors->first('sdt')): ?>
                                <small id="emailHelp" class="form-text text-danger"><?php echo e($errors->first('sdt')); ?></small>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-6">
                            <input class="form-control" type="text" maxlength="255" name="email" placeholder="Địa chỉ Email (bắt buộc 1 trong 2)" value="<?php echo e(old('email')); ?>">
                            <?php if($errors->first('email')): ?>
                                <small id="emailHelp" class="form-text text-danger"><?php echo e($errors->first('email')); ?></small>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-md-12">
                            <textarea class="form-control" type="text" name="ghichu" placeholder="Mô tả cơ bản về bản thân"></textarea>
                            <?php if($errors->first('ghichu')): ?>
                                <small id="emailHelp" class="form-text text-danger"><?php echo e($errors->first('ghichu')); ?></small>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="section-title">
                        <h2><span>Mô tả hoạt động và mục đích quyên gớp</span></h2>
                    </div>
                    <textarea id="mota"  class="form-control" rows="30" name="mota" placeholder="Mô tả về hoạt động quyên gớp"></textarea>
                    <button class="btn btn-success mt-4">Đăng ký hoạt động gây quỹ từ thiện</button>
                </form>
            </div>
        </section>
    </div>
</div>
<!-- /.container -->
<script>
    var inx = <?php echo e((count(old('taikhoan') ?? [1]) ?? 1) - 1); ?>;
    function remove(evnt){
        $(evnt).closest(".form-group.row").remove();
        inx--;
    }
    function add(evnt){
        inx++;
        var clone = $(evnt).closest(".form-group.row").clone();
        clone.find("input")[0].value = '';
        clone.find("input")[0].name = "taikhoan["+inx+"][nganhang]";
        clone.find("input")[1].value = '';
        clone.find("input")[1].name = "taikhoan["+inx+"][ma_taikhoan]";
        clone.find("input")[2].value = '';
        clone.find("input")[2].name = "taikhoan["+inx+"][hoten]";
        clone.find('small').remove();
        clone.find("button").attr('onclick', 'remove(this)');
        clone.find("button").removeClass("btn-primary");
        clone.find("button").addClass("btn-danger");
        clone.find("button").html("Xóa");
        $(evnt).closest(".form-group.row").after(clone);
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout_home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\web\quy-tu-thien\code\quy-tu-thien\resources\views/tuthien/create.blade.php ENDPATH**/ ?>