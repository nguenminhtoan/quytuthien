
<?php if($paginator->hasPages()): ?>
<div class="row">
   <div class="col-sm-12 col-md-5">
      <div class="dataTables_info" id="products-datatable_info" role="status" aria-live="polite">Showing products 1 to 10 of 12</div>
   </div>
   <div class="col-sm-12 col-md-7">
      <div class="dataTables_paginate paging_simple_numbers" id="products-datatable_paginate">
          
         <ul class="pagination pagination-rounded">
            
            <?php if($paginator->onFirstPage()): ?>
                <li class="disabled paginate_button page-item previous"><span class="page-link"><i class="mdi mdi-chevron-left"></i></span></li>
            <?php else: ?>
                <li class="paginate_button page-item previous"><a class="page-link" href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev"><i class="mdi mdi-chevron-left"></i></a></li>
            <?php endif; ?>
            
            <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <?php if(is_string($element)): ?>
                    <li class="disabled page-item"><span><?php echo e($element); ?></span></li>
                <?php endif; ?>

                
                <?php if(is_array($element)): ?>
                    <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($page == $paginator->currentPage()): ?>
                        <li class="active page-item paginate_button "><span class="page-link"><?php echo e($page); ?></span></li>
                        <?php else: ?>
                            <li class="page-item paginate_button "><a class="page-link" href="<?php echo e($url); ?>"><?php echo e($page); ?></a></li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            
            <?php if($paginator->hasMorePages()): ?>
                <li class="paginate_button page-item next"><a class="page-link" href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next"><i class="mdi mdi-chevron-right"></i></a></li>
            <?php else: ?>
                <li class="disabled paginate_button page-item next"><span class="page-link"><i class="mdi mdi-chevron-right"></i></span></li>
            <?php endif; ?>
         </ul>
      </div>
   </div>
</div>
<?php endif; ?><?php /**PATH D:\web\quy-tu-thien\code\quy-tu-thien\resources\views/admin/paginate_table.blade.php ENDPATH**/ ?>