<?php $__env->startSection('content'); ?>
<div class="container">
    <!-- Content
================================================== -->
    <div class="main-content">
        <!-- Begin Article
================================================== -->
        <div class="row">
            <div class="col-sm-4 sp-hidden">
                <div class="sidebar">
                    <div class="sidebar-section">
                        <h5><span><?php echo e($detail->HOTEN); ?></span></h5>

                        <ul style="list-none">
                            <li>
                                <div class="meta-footer-thumb">
                                    <img class="author-thumb-sigin" src="<?php echo e("/storage".$detail->PATH); ?>" alt="<?php echo e($detail -> HOTEN); ?>">
                                </div>
                            </li>
                            <li>Được quyên gớp: <a href="" class="price"><?php echo e(number_format($detail -> SOTIEN)."đ"); ?></a></li>
                            <li>Người tham gia: <?php echo e(number_format($detail -> SONGUOI)); ?></li>
                            <li>Tiếp nhận: <?php echo e(date("Y/m/d" ,strtotime($detail -> BATDAU))); ?> đến <?php echo e(date("Y/m/d" ,strtotime($detail -> KETTHUC))); ?></li>
                            <?php $__currentLoopData = $detail->TAIKHOAN; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                Tài khoản tiếp nhận: 
                                <ul>
                                    
                                    <li>Ngân hàng: <?php echo e($item["NGANHANG"]); ?></li>
                                    <li>Số TK: <?php echo e($item["MA_TAIKHOAN"]); ?> </li>
                                    <li>Chủ sở hữu: <?php echo e($item["HOTEN"]); ?></li>
                                </ul>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <li>Điện thoại: <?php echo e($detail -> DT); ?></li>
                            <li>Địa chỉ: <?php echo e($detail -> DIACHI); ?></li>
                            <li>Ghi chú: <?php echo e($detail -> GHICHU); ?></li>
                        </ul>
                        <a href="/sao-ke/<?php echo e($detail -> ID_TUTHIEN); ?>" class="btn btn-primary mb-2">Sao kê</a>
                        <a href="/quyen-gop/<?php echo e($detail -> ID_TUTHIEN); ?>" class="btn btn-success mb-2">Đóng gớp</a>
                    </div>
                    <div class="sidebar-section">
                        <h5><span>Hoạt động cứu trợ</span></h5>
                        <ul style="list-none">
                            <li>Khoản chi: <a href="" class="price"><?php echo e(number_format($detail -> TONGCHI)."đ"); ?></a></li>
                            <li>Đã cứu trợ: <?php echo e(number_format($detail->TONGHTRO)); ?></li>
                            <li>Thời gian: <?php echo e(date("Y/m/d" ,strtotime($detail -> BATDAUHD))); ?> đến <?php echo e(date("Y/m/d" ,strtotime($detail -> KETTHUCHD))); ?></li>
                        </ul>
                        <a href="/hoat-dong/<?php echo e($detail -> ID_TUTHIEN); ?>" class="btn btn-primary">Chi tiết hoạt động</a>
                    </div>
                </div>
            </div>
            <!-- Sidebar -->
            <div class="col-sm-8">
                <div class="mainheading">
                    <!-- Post Categories -->
                    <!-- End Categories -->
                    <!-- Post Title -->
                    <h1 class="posttitle">Quyên góp cho bà con vùng lũ</h1>
                </div>
                
                <!-- Post Featured Image -->
                <div class="article-post">
                    <form action="/quyen-gop/<?php echo e($id); ?>" method="POST" enctype='multipart/form-data'>
                        <?php echo csrf_field(); ?>
                        <div class="form-group row">
                            <div class="col-md-6">
                                <label for="taikhoan">Số tài khoản <span class="text-danger text-center">*</span></label>
                                <input id="taikhoan" class="form-control" type="number" name="taikhoan" value="<?php echo e(old('taikhoan')); ?>" placeholder="số tài khoản ngân hàng">
                                <?php if($errors->first('taikhoan')): ?>
                                <small id="emailHelp" class="form-text text-danger"><?php echo e($errors->first('taikhoan')); ?></small>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-6">
                                <label>Chủ sở hữu</label>
                                <input class="form-control" type="text" name="ten" placeholder="Họ tên" value="<?php echo e(old('ten')); ?>">
                                <?php if($errors->first('ten')): ?>
                                <small id="emailHelp" class="form-text text-danger"><?php echo e($errors->first('ten')); ?></small>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-6">
                                <label>Số tiền đóng gớp <span class="text-danger text-center">*</span></label>
                                <input class="form-control" type="number" name="sotien" placeholder="Số tiền đóng gớp" value="<?php echo e(old('sotien')); ?>">
                                <?php if($errors->first('sotien')): ?>
                                <small id="emailHelp" class="form-text text-danger"><?php echo e($errors->first('sotien')); ?></small>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-6">
                                <label>Ngày đóng gớp <span class="text-danger text-center">*</span></label>
                                <input class="form-control" type="date" name="thoigian" value="<?php echo e(old('thoigian') ?? date('Y-m-d')); ?>">
                                <?php if($errors->first('thoigian')): ?>
                                <small id="emailHelp" class="form-text text-danger"><?php echo e($errors->first('thoigian')); ?></small>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-6">
                                <label>Chứng từ <span class="text-danger text-center">*</span></label>
                                <input class="form-control" type="file" name="image" accept="image/jpeg,image/png,image/jpg,image/gif,image/tiff,image/svg" value="<?php echo e(old('image')); ?>">
                                <?php if($errors->first('image')): ?>
                                <small id="emailHelp" class="form-text text-danger"><?php echo e($errors->first('image')); ?></small>
                                <?php endif; ?>
                                <small id="emailHelp" class="form-text text-small">Ảnh chụp màn hình chi tiết chuyển khoản hoặc ảnh chụp giấp tờ chuyển khoản</small>
                            </div>
                        </div>
                        <a class="btn btn-info" href="/tu-thien/<?php echo e($id); ?>">Trở lại</a>
                        <button class="btn btn-success">Đóng gớp</button>
                    </form>
                </div>
                <!-- End Prev/Next -->
                <!-- Author Box -->
                <div class="row post-top-meta">
                    <div class="col-md-2">
                        <img class="author-thumb" src="https://www.gravatar.com/avatar/e56154546cf4be74e393c62d1ae9f9d4?s=250&amp;d=mm&amp;r=x" alt="Sal">
                    </div>
                    <div class="col-md-10">
                        <a target="_blank" class="link-dark" href="#">Nhóm phát triển</a>
                        <span class="author-description">Thông tin bạn cung cấp được chúng tôi sử dụng với mục đích thống kê các khoản đóng gớp tạo tính minh bạch, Thông tin tài khoản và chủ sở hữu sẽ được bảo mật tuyệt đối</span>
                    </div>
                </div>
                <!-- Begin Comments
================================================== -->
                <!--End Comments
                ================================================== -->
            </div>
            <div class="col-sm-4 pc-hidden">
                <div class="sidebar-right">
                    <div class="sidebar">
                        <div class="sidebar-section">
                            <h5><span><?php echo e($detail->HOTEN); ?></span></h5>

                            <ul style="list-none">
                                <li>
                                    <div class="meta-footer-thumb">
                                        <img class="author-thumb-sigin" src="<?php echo e($detail->PATH); ?>" alt="<?php echo e($detail -> HOTEN); ?>">
                                    </div>
                                </li>
                                <li>Được quyên gớp: <a href="" class="price"><?php echo e(number_format($detail -> SOTIEN)."đ"); ?></a></li>
                                <li>Người tham gia: <?php echo e(number_format($detail -> SONGUOI)); ?></li>
                                <li>Tiếp nhận: <?php echo e(date("Y/m/d" ,strtotime($detail -> BATDAU))); ?> đến <?php echo e(date("Y/m/d" ,strtotime($detail -> KETTHUC))); ?></li>
                                <?php $__currentLoopData = $detail->TAIKHOAN; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    Tài khoản tiếp nhận: 
                                    <ul>

                                        <li>Ngân hàng: <?php echo e($item["NGANHANG"]); ?></li>
                                        <li>Số TK: <?php echo e($item["MA_TAIKHOAN"]); ?> </li>
                                        <li>Chủ sở hữu: <?php echo e($item["HOTEN"]); ?></li>
                                    </ul>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <li>Điện thoại: <?php echo e($detail -> DT); ?></li>
                                <li>Địa chỉ: <?php echo e($detail -> DIACHI); ?></li>
                                <li>Ghi chú: <?php echo e($detail -> GHICHU); ?></li>
                            </ul>
                            <a href="/sao-ke/<?php echo e($detail -> ID_TUTHIEN); ?>" class="btn btn-primary mb-2">Sao kê</a>
                            <a href="/quyen-gop/<?php echo e($detail -> ID_TUTHIEN); ?>" class="btn btn-success mb-2">Đóng gớp</a>
                        </div>
                        <div class="sidebar-section">
                            <h5><span>Hoạt động cứu trợ</span></h5>
                            <ul style="list-none">
                                <li>Khoản chi: <a href="" class="price"><?php echo e(number_format($detail -> TONGCHI)."đ"); ?></a></li>
                                <li>Đã cứu trợ: <?php echo e(number_format($detail->TONGHTRO)); ?></li>
                                <li>Thời gian: <?php echo e(date("Y/m/d" ,strtotime($detail -> BATDAUHD))); ?> đến <?php echo e(date("Y/m/d" ,strtotime($detail -> KETTHUCHD))); ?></li>
                            </ul>
                            <a href="/hoat-dong/<?php echo e($detail -> ID_TUTHIEN); ?>" class="btn btn-primary">Chi tiết hoạt động</a>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Post -->

            <!-- End Post -->
        </div>
        <!-- End Article
================================================== -->
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout_home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\web\quy-tu-thien\code\quy-tu-thien\resources\views/quyengop/index.blade.php ENDPATH**/ ?>