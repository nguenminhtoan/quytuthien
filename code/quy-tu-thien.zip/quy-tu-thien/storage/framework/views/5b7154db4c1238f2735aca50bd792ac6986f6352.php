
<?php $__env->startSection('content'); ?>
<div class="container">
    <!-- Content
================================================== -->
    <div class="main-content">
        <!-- Begin Article
================================================== -->
        <div class="row">
            <div class="col-sm-4 sp-hidden">
                <div class="sidebar">
                    <div class="sidebar-section">
                        <h5><span>Hoạt động cứu trợ</span></h5>
                        <ul style="list-none">
                            <li>Khoản chi: <a href="" class="price"><?php echo e(number_format($detail -> TONGCHI)."đ"); ?></a></li>
                            <li>Đã cứu trợ: <?php echo e(number_format($detail->TONGHTRO)); ?></li>
                            <li>Thời gian: <?php echo e(date("Y/m/d" ,strtotime($detail -> BATDAUHD))); ?> đến <?php echo e(date("Y/m/d" ,strtotime($detail -> KETTHUCHD))); ?></li>
                        </ul>
                        <a href="/hoat-dong/<?php echo e($detail -> ID_TUTHIEN); ?>" class="btn btn-primary">Chi tiết hoạt động</a>
                    </div>
                    <div class="sidebar-section">
                        <h5><span><?php echo e($detail->HOTEN); ?></span></h5>

                        <ul style="list-none">
                            <li>
                                <div class="meta-footer-thumb">
                                    <img class="author-thumb-sigin" src="<?php echo e("/storage".$detail->PATH); ?>" alt="<?php echo e($detail -> HOTEN); ?>">
                                </div>
                            </li>
                            <li>Được quyên gớp: <a href="" class="price"><?php echo e(number_format($detail -> SOTIEN)."đ"); ?></a></li>
                            <li>Người tham gia: <?php echo e(number_format($detail -> SONGUOI)); ?></li>
                            <li>Tiếp nhận: <?php echo e(date("Y/m/d" ,strtotime($detail -> BATDAU))); ?> đến <?php echo e(date("Y/m/d" ,strtotime($detail -> KETTHUC))); ?></li>
                            <?php $__currentLoopData = $detail->TAIKHOAN; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                Tài khoản tiếp nhận: 
                                <ul>
                                    
                                    <li>Ngân hàng: <?php echo e($item["NGANHANG"]); ?></li>
                                    <li>Số TK: <?php echo e($item["MA_TAIKHOAN"]); ?> </li>
                                    <li>Chủ sở hữu: <?php echo e($item["HOTEN"]); ?></li>
                                </ul>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <li>Điện thoại: <?php echo e($detail -> DT); ?></li>
                            <li>Địa chỉ: <?php echo e($detail -> DIACHI); ?></li>
                            <li>Ghi chú: <?php echo e($detail -> GHICHU); ?></li>
                        </ul>
                        <a href="/sao-ke/<?php echo e($detail -> ID_TUTHIEN); ?>" class="btn btn-primary mb-2">Sao kê</a>
                        <a href="/quyen-gop/<?php echo e($detail -> ID_TUTHIEN); ?>" class="btn btn-success mb-2">Đóng gớp</a>
                    </div>
                </div>
            </div>
            <!-- Sidebar -->
            <div class="col-sm-8">
                <div class="section-title">
                    <h2><span>Các hoạt cứu trợ đã diễn ra</span></h2>
                </div>
                <div class="masonrygrid row listrecent">
                    <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6 grid-item">
                        <div class="card">
                            <a href="/hoat-dong/chi-tiet/<?php echo e($item -> ID_HOATDONG); ?>">
                                <img class="img-fluid" src="<?php echo e("/storage".$item->PATH); ?>" alt="<?php echo e($item->TEN); ?>">
                            </a>
                            <div class="card-block">
                                <h2 class="card-title"><a href="/hoat-dong/chi-tiet/<?php echo e($item -> ID_HOATDONG); ?>"><?php echo e($item->TEN); ?></a></h2>
                                <h4 class="card-text"><?php echo substr(strip_tags($item->MOTA), 0, 200); ?>...</h4>
                                <h6>Tổng chi tiêu hoạt động <?php echo e(number_format($item->SOTIEN)); ?>đ</h6>
                                <div class="metafooter">
                                    <div class="wrapfooter">
                                        <span class="meta-footer-thumb">
                                            <img class="author-thumb" src="<?php echo e("/storage".($item->HINHANH ?? '/image/user/user.jpg')); ?>" alt="Sal">
                                        </span>
                                        <span class="author-meta">
                                            <span class="post-name"><?php echo e($item -> HOTEN); ?></a></span><br/>
                                            <span class="post-date"><?php echo e(date("Y/m/d" ,strtotime($item -> BATDAU))); ?></span>
                                        </span>
                                        <span class="post-read-more"><a href="/hoat-dong/chi-tiet/<?php echo e($item -> ID_HOATDONG); ?>" title="Chi tiết <?php echo e($item->TEN); ?>">Chi tiết</a></span>
                                        <div class="clearfix">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <!-- Pagination -->
                <div class="bottompagination">
                    <div class="navigation">
                        <nav class="pagination">
                            <span class="page-number"> &nbsp; &nbsp; Trang <?php echo e($list->currentPage()); ?> của <?php echo e($list->lastPage()); ?> &nbsp; &nbsp; </span>
                        </nav>
                    </div>
                </div>
                <?php echo e($list->links("paginate")); ?>

            </div>
            <div class="col-sm-4 pc-hidden">
                <div class="sidebar">
                    <div class="sidebar-section">
                        <h5><span><?php echo e($detail->HOTEN); ?></span></h5>

                        <ul style="list-none">
                            <li>
                                <div class="meta-footer-thumb">
                                    <img class="author-thumb-sigin" src="<?php echo e("/storage".$detail->PATH); ?>" alt="<?php echo e($detail -> HOTEN); ?>">
                                </div>
                            </li>
                            <li>Được quyên gớp: <a href="" class="price"><?php echo e(number_format($detail -> SOTIEN)."đ"); ?></a></li>
                            <li>Người tham gia: <?php echo e(number_format($detail -> SONGUOI)); ?></li>
                            <li>Tiếp nhận: <?php echo e(date("Y/m/d" ,strtotime($detail -> BATDAU))); ?> đến <?php echo e(date("Y/m/d" ,strtotime($detail -> KETTHUC))); ?></li>
                            <?php $__currentLoopData = $detail->TAIKHOAN; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                Tài khoản tiếp nhận: 
                                <ul>
                                    
                                    <li>Ngân hàng: <?php echo e($item["NGANHANG"]); ?></li>
                                    <li>Số TK: <?php echo e($item["MA_TAIKHOAN"]); ?> </li>
                                    <li>Chủ sở hữu: <?php echo e($item["HOTEN"]); ?></li>
                                </ul>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <li>Điện thoại: <?php echo e($detail -> DT); ?></li>
                            <li>Địa chỉ: <?php echo e($detail -> DIACHI); ?></li>
                            <li>Ghi chú: <?php echo e($detail -> GHICHU); ?></li>
                        </ul>
                        <a href="/sao-ke/<?php echo e($detail -> ID_TUTHIEN); ?>" class="btn btn-primary mb-2">Sao kê</a>
                        <a href="/quyen-gop/<?php echo e($detail -> ID_TUTHIEN); ?>" class="btn btn-success mb-2">Đóng gớp</a>
                    </div>
                    <div class="sidebar-section">
                        <h5><span>Hoạt động cứu trợ</span></h5>
                        <ul style="list-none">
                            <li>Khoản chi: <a href="" class="price"><?php echo e(number_format($detail -> TONGCHI)."đ"); ?></a></li>
                            <li>Đã cứu trợ: <?php echo e(number_format($detail->TONGHTRO)); ?></li>
                            <li>Thời gian: <?php echo e(date("Y/m/d" ,strtotime($detail -> BATDAUHD))); ?> đến <?php echo e(date("Y/m/d" ,strtotime($detail -> KETTHUCHD))); ?></li>
                        </ul>
                        <a href="/hoat-dong/<?php echo e($detail -> ID_TUTHIEN); ?>" class="btn btn-primary">Chi tiết hoạt động</a>
                    </div>
                </div>
            </div>
            <!-- Post -->

            <!-- End Post -->
        </div>
        <!-- End Article
================================================== -->
    </div>
</div>
<!-- /.container -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout_home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\web\quy-tu-thien\code\quy-tu-thien\resources\views/hoatdong/index.blade.php ENDPATH**/ ?>