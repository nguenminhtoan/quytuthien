
<?php $__env->startSection('content'); ?>
<section class="slider_section">
     <div id="main_slider" class="carousel slide banner-main" data-ride="carousel">

        <div class="carousel-inner">
           <div class="carousel-item active">
               <img class="first-slide" src="/assets/images/banner1.jpg" alt="First slide">
              <div class="container row">
                 <div class="carousel-caption relative">
                    <h1>Sự Thật<br> <strong class="black_bold"> Có phải</strong><br>
                       <strong class="yellow_bold">97 tỷ </strong></h1>
                    <p>Để làm sáng tỏ xự việc. Các bạn ai đã đóng gớp cho Hưng<br>
                       Xin hãy khai báo đóng gớp trong hoạt động của Hưng </p>
                    <a  href="#">Kê khai đóng gớp</a>
                 </div>
              </div>
           </div>
        </div>
        <a class="carousel-control-prev" href="#main_slider" role="button" data-slide="prev">
        <i class='fa fa-angle-right'></i>
        </a>
        <a class="carousel-control-next" href="#main_slider" role="button" data-slide="next">
        <i class='fa fa-angle-left'></i>
        </a>

     </div>

  </section>
<div class="container">
    <div class="main-content">
        <section class="featured-posts">
            <div class="section-title">
                <h2><span>Nổi bật</span></h2>
            </div>
            <div class="row listfeaturedtag">
                <?php $__currentLoopData = $listhost; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <!-- begin post -->
                <div class="col-sm-6">
                    <div class="card">
                        <div class="row">
                            <div class="col-md-5 wrapthumbnail">
                                <a href="/tu-thien/<?php echo e($item->ID_TUTHIEN); ?>">
                                    <div class="thumbnail" style="background-image:url('<?php echo e("/storage".$item->HINHANH); ?>');">
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-7">
                                <div class="card-block">
                                    <h2 class="card-title"><a href="/tu-thien/<?php echo e($item->ID_TUTHIEN); ?>"><?php echo e($item -> TENQUY); ?></a></h2>
                                    <h6>Được quyên gớp: <?php echo e(number_format($item -> SOTIEN)."đ"); ?></h6>
                                    <h6>Người tham gia: <?php echo e(number_format($item -> SONGUOI)); ?></h6>
                                    <h4 class="card-text"><?php echo substr(strip_tags($item->MOTA), 0, 230); ?>...</h4>
                                    <div class="metafooter">
                                        <div class="wrapfooter">
                                            <span class="meta-footer-thumb">
                                                <img class="author-thumb" src="<?php echo e('/storage'.$item -> PATH); ?>" alt="<?php echo e($item -> PHUTRACH); ?>">
                                            </span>
                                            <span class="author-meta">
                                                <span class="post-name"><?php echo e($item -> PHUTRACH); ?></span><br/>
                                                <span class="post-date"><?php echo e(date("Y/m/d" ,strtotime($item -> BATDAU))); ?></span>
                                            </span>
                                            <span class="post-read-more"><a href="/quyen-gop/<?php echo e($item -> ID_TUTHIEN); ?>" title="Chi tiết<?php echo e($item -> TENQUY); ?>">Đóng gớp</a></span>
                                            <div class="clearfix">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- end post -->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </section>
        <!-- Posts Index
        ================================================== -->
        <section class="recent-posts row">
            <div class="col-sm-4">
                <div class="sidebar">
                    <div class="sidebar-section">
                        <h5><span>Nhận thông báo</span></h5>
                        <!-- Go to your Mailchimp account/Lists/Sign Up Forms/Embedded forms and replace the code below with your own  -->
                        <!-- Begin MailChimp Signup Form -->
                        <link href="https://cdn-images.mailchimp.com/embedcode/classic-10_7.css" rel="stylesheet" type="text/css">
                        <div id="mc_embed_signup">
                            <form action="https://wowthemes.us11.list-manage.com/subscribe/post?u=8aeb20a530e124561927d3bd8&amp;id=8c3d2d214b" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="validate" target="_blank" novalidate>
                                <div id="mc_embed_signup_scroll">
                                    <h2>Đăng ký để được nhận thông báo các hoạt động thiện nguyện</h2>
                                    <div class="mc-field-group">
                                        <input type="email" value="" name="EMAIL" class="required email" id="mce-EMAIL" placeholder="Địa chỉ email">
                                    </div>
                                    <div class="clear">
                                        <button type="submit" value="Subscribe" name="subscribe" id="mc-embedded-subscribe" class="button">Đăng ký</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <!--End mc_embed_signup-->
                    </div>

                </div>
            </div>
            <div class="col-sm-8">
                <div class="section-title">
                    <h2><span>Tất cả</span></h2>
                </div>
                <div class="masonrygrid row listrecent">
                    <!-- begin post -->
                    <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-12 grid-item">
                        <div class="card">
                            <div class="card-block">
                                <div class="metaheader">
                                    <div class="wrapheader">
                                        <span class="meta-footer-thumb">
                                            <img class="author-thumb" src="<?php echo e('/storage'.$item -> PATH); ?>" alt="<?php echo e($item -> PHUTRACH); ?>">
                                        </span>
                                        <span class="author-meta">
                                            <span class="post-name"><?php echo e($item -> PHUTRACH); ?></span><br/>
                                            <span class="post-date"><?php echo e(date("Y/m/d" ,strtotime($item -> BATDAU))); ?></span>
                                        </span>
                                        <span class="post-read-more"><a href="/quyen-gop/<?php echo e($item -> ID_TUTHIEN); ?>" title="Chi tiết<?php echo e($item -> TENQUY); ?>">Đóng gớp</a></span>
                                        <div class="clearfix">
                                        </div>
                                    </div>
                                </div>
                                <h2 class="card-title"><a href="/tu-thien/<?php echo e($item->ID_TUTHIEN); ?>"><?php echo e($item -> TENQUY); ?></a></h2>
                                <h4 class="card-text">
                                    <?php echo substr( strip_tags($item->MOTA), 0, 700); ?><?php echo e(strlen($item->MOTA) > 750 ? "..." : ""); ?> 
                                    <a href="/tu-thien/<?php echo e($item->ID_TUTHIEN); ?>" >Chi tiết</a>
                                </h4>
                                <h6>Số tiền được quyên gớp: <?php echo e(number_format($item -> SOTIEN)."đ"); ?></h6>
                                <h6>Người tham gia: <?php echo e(number_format($item -> SONGUOI)); ?></h6>
                            </div>
                            <div class="img-card">
                                <a href="/tu-thien/<?php echo e($item->ID_TUTHIEN); ?>">
                                    <img class="img-fluid" src="<?php echo e("/storage".$item->HINHANH); ?>" alt="<?php echo e($item -> TENQUY); ?>">
                                </a>
                            </div>
                                
                            <div class="card-block pb-2">
                                <div class="metafooter">
                                    <div class="wrapfooter mt-0">
                                        <ul class="footer-icon">
                                            <li><a href="/hoat-dong/<?php echo e($item -> ID_TUTHIEN); ?>"><i class="fa fa-instagram"></i>Hoạt động</a></li>
                                            <li><a href="/quyen-gop/<?php echo e($item -> ID_TUTHIEN); ?>"><i class="fa fa-user"></i>Tham gia</a></li>
                                            <li><a href=""><i class="fa fa-share"></i>Chia sẻ</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <!-- end post -->
                    
                </div>
                <!-- Pagination -->
                <div class="bottompagination">
                    <div class="navigation">
                        <nav class="pagination">
                            <span class="page-number"> &nbsp; &nbsp; Trang <?php echo e($list->currentPage()); ?> của <?php echo e($list->lastPage()); ?> &nbsp; &nbsp; </span>
                        </nav>
                    </div>
                </div>
                <?php echo e($list->links("paginate")); ?>

            </div>
        </section>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout_home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\web\quy-tu-thien\code\quy-tu-thien\resources\views/home/index.blade.php ENDPATH**/ ?>