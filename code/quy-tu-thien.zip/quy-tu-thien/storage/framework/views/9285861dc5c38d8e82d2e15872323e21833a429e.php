
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="main-content">		
        <!-- Category Archive
================================================== -->
        <section class="recent-posts row">
            <div class="col-sm-4">
                <div class="sidebar">
                    <div class="sidebar-section">
                        <h5><span>Người kêu gọi quyên gớp</span></h5>

                        <ul style="list-none">
                            <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="/tu-thien/tim-kiem/<?php echo e($item -> ID_NGUOIDUNG); ?>"><?php echo e($item -> HOTEN); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="/tu-thien">Tất cả</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-sm-8">
                <div class="section-title">
                    <h2><span>Các hoạt động từ hiện đang diễn ra</span></h2>
                </div>
                <div class="masonrygrid row listrecent">
                    <!-- begin post -->
                    <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-12 grid-item">
                        <div class="card">
                            <div class="card-block">
                                <div class="metaheader">
                                    <div class="wrapheader">
                                        <span class="meta-footer-thumb">
                                            <img class="author-thumb" src="<?php echo e('/storage'.$item -> PATH); ?>" alt="<?php echo e($item -> PHUTRACH); ?>">
                                        </span>
                                        <span class="author-meta">
                                            <span class="post-name"><?php echo e($item -> PHUTRACH); ?></span><br/>
                                            <span class="post-date"><?php echo e(date("Y/m/d" ,strtotime($item -> BATDAU))); ?></span>
                                        </span>
                                        <span class="post-read-more"><a href="/quyen-gop/<?php echo e($item -> ID_TUTHIEN); ?>" title="Chi tiết<?php echo e($item -> TENQUY); ?>">Đóng gớp</a></span>
                                        <div class="clearfix">
                                        </div>
                                    </div>
                                </div>
                                <h2 class="card-title"><a href="/tu-thien/<?php echo e($item->ID_TUTHIEN); ?>"><?php echo e($item -> TENQUY); ?></a></h2>
                                <h4 class="card-text">
                                    <?php echo substr( strip_tags($item->MOTA), 0, 700); ?><?php echo e(strlen($item->MOTA) > 750 ? "..." : ""); ?> 
                                    <a href="/tu-thien/<?php echo e($item->ID_TUTHIEN); ?>" >Chi tiết</a>
                                </h4>
                                <h6>Số tiền được quyên gớp: <?php echo e(number_format($item -> SOTIEN)."đ"); ?></h6>
                                <h6>Người tham gia: <?php echo e(number_format($item -> SONGUOI)); ?></h6>
                            </div>
                            <div class="img-card">
                                <a href="/tu-thien/<?php echo e($item->ID_TUTHIEN); ?>">
                                    <img class="img-fluid" src="<?php echo e("/storage".$item->HINHANH); ?>" alt="<?php echo e($item -> TENQUY); ?>">
                                </a>
                            </div>
                                
                            <div class="card-block pb-2">
                                <div class="metafooter">
                                    <div class="wrapfooter mt-0">
                                        <ul class="footer-icon">
                                            <li><a href="/hoat-dong/<?php echo e($item -> ID_TUTHIEN); ?>"><i class="fa fa-instagram"></i>Hoạt động</a></li>
                                            <li><a href="/quyen-gop/<?php echo e($item -> ID_TUTHIEN); ?>"><i class="fa fa-user"></i>Tham gia</a></li>
                                            <li><a href=""><i class="fa fa-share"></i>Chia sẻ</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <!-- end post -->
                    
                </div>
                <!-- Pagination -->
                <div class="bottompagination">
                    <div class="navigation">
                        <nav class="pagination">
                            <span class="page-number"> &nbsp; &nbsp; Trang <?php echo e($list->currentPage()); ?> của <?php echo e($list->lastPage()); ?> &nbsp; &nbsp; </span>
                        </nav>
                    </div>
                </div>
                <?php echo e($list->links("paginate")); ?>

            </div>
        </section>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout_home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\web\quy-tu-thien\code\quy-tu-thien\resources\views/tuthien/index.blade.php ENDPATH**/ ?>